﻿// This code requires the Nuget package Microsoft.AspNet.WebApi.Client to be installed.
// Instructions for doing this in Visual Studio:
// Tools -> Nuget Package Manager -> Package Manager Console
// Install-Package Microsoft.AspNet.WebApi.Client

using HackatonGrupo11.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;

using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace HackatonGrupo11
{

    public class StringTable
    {
        public string[] ColumnNames { get; set; }
        public string[,] Values { get; set; }
    }

    public class webservice
    {
        public async Task<List<Resultado>> InvokeRequestResponseService()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Profile");
            sb.AppendLine("1");
            using (var client = new HttpClient())
            {
                var scoreRequest = new
                {
                    GlobalParameters = new Dictionary<string, string>()
                    {
                            { "Data", "profile\n1" },
                    }
                };
                const string apiKey = "YHJiRdDxNUzbz+4aU/Rlt0K98MwIBN2pTs++wVEIpjluVYbm1BaVFZ4MCZeSeq6AvPyMXxVv/NlxTYtF/TeCAQ=="; // Replace this with the API key for the web service
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/ca0d0ec44f244738b1faa8f8f6cdbf5f/services/b1427db95c1e48a19d14ea24df60faff/execute?api-version=2.0&details=true");

                // WARNING: The 'await' statement below can result in a deadlock if you are calling this code from the UI thread of an ASP.Net application.
                // One way to address this would be to call ConfigureAwait(false) so that the execution does not attempt to resume on the original context.
                // For instance, replace code such as:
                //      result = await DoSomeTask()
                // with the following:
                //      result = await DoSomeTask().ConfigureAwait(false)

                try
                {
                    HttpResponseMessage response = await client.PostAsJsonAsync("", scoreRequest);

                    if (response.IsSuccessStatusCode)
                    {
                        string result = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Result: {0}", result);

                        var clusterDTO = JsonConvert.DeserializeObject<JsonValores>(result);

                        List<Resultado> valores = new List<Resultado>();
                        foreach (var v in clusterDTO.Results.output1.value.Values)
                        {
                            valores.Add(new Resultado
                            {
                                asset = v[0],
                                count = Convert.ToInt32(v[1])
                            });
                        }
                        return valores;
                    }
                    else
                    {
                        Console.WriteLine(string.Format("The request failed with status code: {0}", response.StatusCode));

                        // Print the headers - they include the requert ID and the timestamp, which are useful for debugging the failure
                        Console.WriteLine(response.Headers.ToString());

                        string responseContent = await response.Content.ReadAsStringAsync();
                        Console.WriteLine(responseContent);
                        return null;
                    }
                }
                catch (Exception e){
                    Console.WriteLine(string.Format("The request failed: {0}, {1}", e.Message,e.InnerException.Message));
                    return null;                    
                }


            }
        }
    }
}
