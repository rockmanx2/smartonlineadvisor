﻿namespace HackatonGrupo11.Models
{
    public class DateValue
    {
        public string Date { get; set; }
        public string Value { get; set; }
    }
}