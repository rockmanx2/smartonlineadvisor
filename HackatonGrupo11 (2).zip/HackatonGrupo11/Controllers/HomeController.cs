﻿using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System;
using System.IO;
using System.Collections.Generic;

namespace HackatonGrupo11.Controllers
{
    public class HomeController : Controller
    {
        public async Task<ActionResult> index()
        {
            webservice novo = new webservice();

            ViewBag.Valores = await novo.InvokeRequestResponseService(); ;
            return View();
        }

        public class DateValue
        {
            public string Value { get; set; }
            public string Date { get; set; }
        }
        [HttpPost]
        public ActionResult File()
        {
            var file = Request.Files["UploadedImage"];

            var lista = new List<DateValue>();
            if (file != null)
            {
                string text = ExtractTextFromPdf(file.InputStream);

                string[] doc;
                doc = text.Split(default(string[]), StringSplitOptions.RemoveEmptyEntries);
                string valorRegEx = @"\d+\.\d+\,\d+";
                string dataRegEx = @"\d+\/\d+\/\d+";
                for (int x = 0; x < doc.Length; x++)
                {
                    if (Regex.IsMatch(doc[x], valorRegEx))
                    {
                        lista.Add(new DateValue { Value = doc[x] });
                        doc[x] = String.Empty;
                    }
                }
                int i = 0;
                for (int j = 0; j < doc.Length; j++)
                {
                    if (Regex.IsMatch(doc[j], dataRegEx))
                    {
                        lista[i].Date = doc[j];
                        doc[j] = String.Empty;
                        i++;
                    }
                }
            }
            return Json(lista);
        }
        
        public static string ExtractTextFromPdf(Stream stream)
        {
            using (PdfReader reader = new PdfReader(stream))
            {
                StringBuilder text = new StringBuilder();
                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    text.Append(PdfTextExtractor.GetTextFromPage(reader, i));
                }
                return text.ToString();
            }
        }
    }
}